import { useState, useEffect } from 'react'
import { useApp } from '../context/AppContext'
import { Show } from '../types'
import * as api from '../services/api'
import './AdminDashboard.css'

const AdminDashboard = () => {
  const { shows, fetchShows, setError } = useApp()
  const [formData, setFormData] = useState({
    name: '',
    startTime: '',
    totalSeats: '',
  })
  const [loading, setLoading] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    fetchShows()
  }, [fetchShows])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    setFormError(null)
    setSuccess(null)
  }

  const validateForm = () => {
    if (!formData.name.trim()) {
      setFormError('Show name is required')
      return false
    }
    if (!formData.startTime) {
      setFormError('Start time is required')
      return false
    }
    if (!formData.totalSeats || parseInt(formData.totalSeats) < 1) {
      setFormError('Total seats must be at least 1')
      return false
    }
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setFormError(null)
    setSuccess(null)

    if (!validateForm()) {
      return
    }

    try {
      setLoading(true)
      await api.createShow({
        name: formData.name,
        startTime: new Date(formData.startTime).toISOString(),
        totalSeats: parseInt(formData.totalSeats),
      })
      setSuccess('Show created successfully!')
      setFormData({ name: '', startTime: '', totalSeats: '' })
      fetchShows()
    } catch (error: any) {
      setFormError(error.response?.data?.error || error.message || 'Failed to create show')
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>

      <div className="admin-content">
        <div className="create-show-section">
          <h2>Create New Show</h2>
          <form onSubmit={handleSubmit} className="show-form">
            <div className="form-group">
              <label htmlFor="name">Show Name *</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Enter show name"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="startTime">Start Time *</label>
              <input
                type="datetime-local"
                id="startTime"
                name="startTime"
                value={formData.startTime}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="totalSeats">Total Seats *</label>
              <input
                type="number"
                id="totalSeats"
                name="totalSeats"
                value={formData.totalSeats}
                onChange={handleInputChange}
                placeholder="Enter total seats"
                min="1"
                required
              />
            </div>

            {formError && <div className="error-message">{formError}</div>}
            {success && <div className="success-message">{success}</div>}

            <button type="submit" className="submit-button" disabled={loading}>
              {loading ? 'Creating...' : 'Create Show'}
            </button>
          </form>
        </div>

        <div className="shows-list-section">
          <h2>All Shows ({shows.length})</h2>
          {shows.length === 0 ? (
            <div className="empty-state">No shows created yet.</div>
          ) : (
            <div className="shows-list">
              {shows.map((show) => (
                <div key={show.id} className="show-item">
                  <div className="show-info">
                    <h3>{show.name}</h3>
                    <p className="show-time">{formatDate(show.start_time)}</p>
                    <p className="show-seats">
                      {show.total_seats - (show.booked_seats_count || 0)} / {show.total_seats} seats available
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default AdminDashboard



