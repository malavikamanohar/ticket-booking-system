import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { Show, Booking, User } from '../types'
import * as api from '../services/api'

interface AppContextType {
  user: User | null
  shows: Show[]
  bookings: Booking[]
  loading: boolean
  error: string | null
  setUser: (user: User | null) => void
  fetchShows: () => Promise<void>
  fetchBookings: (userId: string) => Promise<void>
  setError: (error: string | null) => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export const useApp = () => {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error('useApp must be used within AppProvider')
  }
  return context
}

interface AppProviderProps {
  children: ReactNode
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [shows, setShows] = useState<Show[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Initialize with a mock user
  useEffect(() => {
    const mockUser: User = {
      id: `user_${Date.now()}`,
      name: 'Guest User',
      role: 'user'
    }
    setUser(mockUser)
  }, [])

  const fetchShows = async () => {
    try {
      setLoading(true)
      setError(null)
      const data = await api.getShows()
      setShows(data.shows || [])
    } catch (err: any) {
      setError(err.message || 'Failed to fetch shows')
      console.error('Error fetching shows:', err)
    } finally {
      setLoading(false)
    }
  }

  const fetchBookings = async (userId: string) => {
    try {
      setLoading(true)
      setError(null)
      const data = await api.getUserBookings(userId)
      setBookings(data.bookings || [])
    } catch (err: any) {
      setError(err.message || 'Failed to fetch bookings')
      console.error('Error fetching bookings:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (user) {
      fetchShows()
    }
  }, [user])

  return (
    <AppContext.Provider
      value={{
        user,
        shows,
        bookings,
        loading,
        error,
        setUser,
        fetchShows,
        fetchBookings,
        setError
      }}
    >
      {children}
    </AppContext.Provider>
  )
}



