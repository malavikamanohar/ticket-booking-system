const fs = require('fs');
const path = require('path');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const envPath = path.join(__dirname, '.env');

function updatePassword() {
  console.log('\n=== PostgreSQL Password Update ===\n');
  console.log('Current .env file:');
  if (fs.existsSync(envPath)) {
    const content = fs.readFileSync(envPath, 'utf8');
    console.log(content);
  }
  
  rl.question('\nEnter your PostgreSQL password for user "postgres": ', (password) => {
    if (!password || password.trim() === '') {
      console.log('\n❌ Password cannot be empty!');
      rl.close();
      return;
    }

    // Read current .env
    let envContent = '';
    if (fs.existsSync(envPath)) {
      envContent = fs.readFileSync(envPath, 'utf8');
    }

    // Update password
    if (envContent.includes('DB_PASSWORD=')) {
      envContent = envContent.replace(/DB_PASSWORD=.*/g, `DB_PASSWORD=${password.trim()}`);
    } else {
      envContent += `\nDB_PASSWORD=${password.trim()}\n`;
    }

    // Write back
    fs.writeFileSync(envPath, envContent, 'utf8');
    console.log('\n✅ Password updated in .env file!');
    console.log('\nNext steps:');
    console.log('1. Run: node src/db/createDatabase.js');
    console.log('2. Run: npm run migrate');
    console.log('3. Run: npm run dev');
    rl.close();
  });
}

updatePassword();


