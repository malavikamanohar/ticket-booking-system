const pool = require('../db/config');

class Booking {
  static async create(showId, userId, seatNumbers) {
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');

      // Check if show exists
      const showResult = await client.query('SELECT * FROM shows WHERE id = $1', [showId]);
      if (showResult.rows.length === 0) {
        throw new Error('Show not found');
      }

      const show = showResult.rows[0];

      // Validate seat numbers
      if (seatNumbers.some(seat => seat < 1 || seat > show.total_seats)) {
        throw new Error('Invalid seat numbers');
      }

      // Check for conflicts using SELECT FOR UPDATE to lock rows
      const conflictQuery = `
        SELECT seat_numbers 
        FROM bookings 
        WHERE show_id = $1 
        AND (
          status = 'CONFIRMED' 
          OR (status = 'PENDING' AND expires_at > NOW())
        )
        FOR UPDATE
      `;
      const conflictResult = await client.query(conflictQuery, [showId]);

      const conflictingSeats = new Set();
      conflictResult.rows.forEach(booking => {
        booking.seat_numbers.forEach(seat => conflictingSeats.add(seat));
      });

      const requestedSeats = new Set(seatNumbers);
      const hasConflict = seatNumbers.some(seat => conflictingSeats.has(seat));

      if (hasConflict) {
        await client.query('ROLLBACK');
        throw new Error('Some seats are already booked or pending');
      }

      // Set expiry time (2 minutes from now)
      const expiresAt = new Date(Date.now() + 2 * 60 * 1000);

      // Create booking
      const insertQuery = `
        INSERT INTO bookings (show_id, user_id, seat_numbers, status, expires_at)
        VALUES ($1, $2, $3, 'PENDING', $4)
        RETURNING *
      `;
      const insertResult = await client.query(insertQuery, [
        showId,
        userId,
        seatNumbers,
        expiresAt
      ]);

      await client.query('COMMIT');
      return insertResult.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  static async confirm(bookingId) {
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');

      // Check if booking exists and is still pending
      const bookingResult = await client.query(
        'SELECT * FROM bookings WHERE id = $1 FOR UPDATE',
        [bookingId]
      );

      if (bookingResult.rows.length === 0) {
        throw new Error('Booking not found');
      }

      const booking = bookingResult.rows[0];

      if (booking.status !== 'PENDING') {
        throw new Error(`Booking is already ${booking.status}`);
      }

      if (new Date(booking.expires_at) < new Date()) {
        // Mark as failed if expired
        await client.query(
          'UPDATE bookings SET status = $1 WHERE id = $2',
          ['FAILED', bookingId]
        );
        await client.query('COMMIT');
        throw new Error('Booking has expired');
      }

      // Check for conflicts again before confirming
      const conflictQuery = `
        SELECT id 
        FROM bookings 
        WHERE show_id = $1 
        AND id != $2
        AND (
          status = 'CONFIRMED' 
          OR (status = 'PENDING' AND expires_at > NOW())
        )
        AND seat_numbers && $3::integer[]
      `;
      const conflictResult = await client.query(conflictQuery, [
        booking.show_id,
        bookingId,
        booking.seat_numbers
      ]);

      if (conflictResult.rows.length > 0) {
        await client.query(
          'UPDATE bookings SET status = $1 WHERE id = $2',
          ['FAILED', bookingId]
        );
        await client.query('COMMIT');
        throw new Error('Seats are no longer available');
      }

      // Confirm booking
      await client.query(
        'UPDATE bookings SET status = $1, expires_at = NULL WHERE id = $2',
        ['CONFIRMED', bookingId]
      );

      await client.query('COMMIT');
      
      const updatedResult = await client.query('SELECT * FROM bookings WHERE id = $1', [bookingId]);
      return updatedResult.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  static async findById(bookingId) {
    const query = 'SELECT * FROM bookings WHERE id = $1';
    const result = await pool.query(query, [bookingId]);
    return result.rows[0];
  }

  static async findByUserId(userId) {
    const query = `
      SELECT b.*, s.name as show_name, s.start_time
      FROM bookings b
      JOIN shows s ON b.show_id = s.id
      WHERE b.user_id = $1
      ORDER BY b.created_at DESC
    `;
    const result = await pool.query(query, [userId]);
    return result.rows;
  }

  static async expirePendingBookings() {
    const query = `
      UPDATE bookings 
      SET status = 'FAILED'
      WHERE status = 'PENDING' 
      AND expires_at < NOW()
      RETURNING *
    `;
    const result = await pool.query(query);
    return result.rows;
  }
}

module.exports = Booking;

