const Booking = require('../models/Booking');

// Run expiry job every 30 seconds
function startExpiryJob() {
  setInterval(async () => {
    try {
      const expired = await Booking.expirePendingBookings();
      if (expired.length > 0) {
        console.log(`Expired ${expired.length} pending bookings`);
      }
    } catch (error) {
      console.error('Error in expiry job:', error);
    }
  }, 30000); // Check every 30 seconds
}

module.exports = startExpiryJob;



