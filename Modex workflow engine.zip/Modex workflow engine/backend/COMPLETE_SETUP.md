# ⚡ FAST SETUP - Complete Now!

## Quick Password Update

**Run this ONE command** (replace `YOUR_PASSWORD` with your actual PostgreSQL password):

```powershell
cd backend
(Get-Content .env) -replace 'DB_PASSWORD=postgres', 'DB_PASSWORD=YOUR_PASSWORD' | Set-Content .env
```

**Example:**
```powershell
(Get-Content .env) -replace 'DB_PASSWORD=postgres', 'DB_PASSWORD=mypassword123' | Set-Content .env
```

## Then Run These 3 Commands:

```powershell
node src/db/createDatabase.js
npm run migrate
npm run dev
```

## Done! 🎉

Backend will be running on `http://localhost:3001`

Then start frontend in another terminal:
```powershell
cd frontend
npm run dev
```

---

**Can't remember your password?**
- Check pgAdmin if installed
- Or reset it: Open pgAdmin → Right-click PostgreSQL server → Properties → Change password

