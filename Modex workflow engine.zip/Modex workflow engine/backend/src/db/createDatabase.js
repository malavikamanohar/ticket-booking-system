require('dotenv').config();
const { Client } = require('pg');

async function createDatabase() {
  // Connect to default postgres database to create our database
  const client = new Client({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: 'postgres', // Connect to default database
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
  });

  try {
    await client.connect();
    console.log('Connected to PostgreSQL');

    const dbName = process.env.DB_NAME || 'ticket_booking';
    
    // Check if database exists
    const checkResult = await client.query(
      `SELECT 1 FROM pg_database WHERE datname = $1`,
      [dbName]
    );

    if (checkResult.rows.length > 0) {
      console.log(`Database '${dbName}' already exists`);
    } else {
      // Create database
      await client.query(`CREATE DATABASE ${dbName}`);
      console.log(`Database '${dbName}' created successfully`);
    }
  } catch (error) {
    console.error('Error creating database:', error.message);
    if (error.message.includes('password authentication failed')) {
      console.error('\n❌ Password authentication failed!');
      console.error('Please update DB_PASSWORD in backend/.env with your PostgreSQL password');
    }
    process.exit(1);
  } finally {
    await client.end();
  }
}

createDatabase();


