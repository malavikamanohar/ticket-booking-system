import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { SeatInfo, Booking } from '../types'
import * as api from '../services/api'
import './BookingPage.css'

const BookingPage = () => {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { user, setError } = useApp()
  const [show, setShow] = useState<any>(null)
  const [seatInfo, setSeatInfo] = useState<SeatInfo | null>(null)
  const [selectedSeats, setSelectedSeats] = useState<number[]>([])
  const [loading, setLoading] = useState(true)
  const [bookingLoading, setBookingLoading] = useState(false)
  const [booking, setBooking] = useState<Booking | null>(null)
  const [error, setLocalError] = useState<string | null>(null)
  const [pollingInterval, setPollingInterval] = useState<NodeJS.Timeout | null>(null)
  const seatRefs = useRef<{ [key: number]: HTMLButtonElement | null }>({})

  useEffect(() => {
    if (!id) {
      navigate('/')
      return
    }

    fetchShowData()

    // Poll for seat availability updates every 5 seconds
    const interval = setInterval(() => {
      if (id) {
        fetchSeatInfo(parseInt(id))
      }
    }, 5000)

    setPollingInterval(interval)

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [id, navigate])

  const fetchShowData = async () => {
    if (!id) return

    try {
      setLoading(true)
      const [showData, seatsData] = await Promise.all([
        api.getShow(parseInt(id)),
        api.getAvailableSeats(parseInt(id)),
      ])
      setShow(showData.show)
      setSeatInfo(seatsData)
    } catch (error: any) {
      setLocalError(error.response?.data?.error || error.message || 'Failed to load show')
    } finally {
      setLoading(false)
    }
  }

  const fetchSeatInfo = async (showId: number) => {
    try {
      const seatsData = await api.getAvailableSeats(showId)
      setSeatInfo(seatsData)
    } catch (error) {
      console.error('Error fetching seat info:', error)
    }
  }

  const handleSeatClick = (seatNumber: number) => {
    if (!seatInfo) return

    const isAvailable = seatInfo.availableSeats.includes(seatNumber)
    const isBooked = seatInfo.bookedSeats.includes(seatNumber)
    const isPending = seatInfo.pendingSeats.includes(seatNumber)

    if (isBooked || isPending) {
      return // Can't select booked or pending seats
    }

    setSelectedSeats((prev) => {
      if (prev.includes(seatNumber)) {
        return prev.filter((s) => s !== seatNumber)
      } else {
        return [...prev, seatNumber]
      }
    })
  }

  const handleBooking = async () => {
    if (!id || !user || selectedSeats.length === 0) {
      setLocalError('Please select at least one seat')
      return
    }

    try {
      setBookingLoading(true)
      setLocalError(null)

      const bookingData = await api.createBooking({
        showId: parseInt(id),
        userId: user.id,
        seatNumbers: selectedSeats,
      })

      setBooking(bookingData.booking)
      setSelectedSeats([])

      // Confirm booking immediately
      try {
        const confirmedBooking = await api.confirmBooking(bookingData.booking.id)
        setBooking(confirmedBooking.booking)
        fetchSeatInfo(parseInt(id))
      } catch (confirmError: any) {
        setLocalError(confirmError.response?.data?.error || 'Booking created but confirmation failed')
      }
    } catch (error: any) {
      setLocalError(error.response?.data?.error || error.message || 'Failed to create booking')
      fetchSeatInfo(parseInt(id)) // Refresh seat info
    } finally {
      setBookingLoading(false)
    }
  }

  const getSeatStatus = (seatNumber: number): 'available' | 'booked' | 'pending' | 'selected' => {
    if (!seatInfo) return 'available'
    if (seatInfo.bookedSeats.includes(seatNumber)) return 'booked'
    if (seatInfo.pendingSeats.includes(seatNumber)) return 'pending'
    if (selectedSeats.includes(seatNumber)) return 'selected'
    return 'available'
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (loading) {
    return (
      <div className="booking-page">
        <div className="loading">Loading show details...</div>
      </div>
    )
  }

  if (error || !show || !seatInfo) {
    return (
      <div className="booking-page">
        <div className="error">
          {error || 'Show not found'}
          <button onClick={() => navigate('/')} className="back-button">
            Go Back
          </button>
        </div>
      </div>
    )
  }

  const seatsPerRow = Math.ceil(Math.sqrt(seatInfo.totalSeats))
  const rows = Math.ceil(seatInfo.totalSeats / seatsPerRow)

  return (
    <div className="booking-page">
      <div className="booking-header">
        <h1>{show.name}</h1>
        <p className="show-time">{formatDate(show.start_time)}</p>
        <button onClick={() => navigate('/')} className="back-button">
          ← Back to Shows
        </button>
      </div>

      {localError && <div className="error-message">{localError}</div>}
      {booking && (
        <div className={`booking-status ${booking.status.toLowerCase()}`}>
          <h3>Booking {booking.status}</h3>
          <p>Seats: {booking.seat_numbers.join(', ')}</p>
          <p>Status: {booking.status}</p>
        </div>
      )}

      <div className="seat-selection">
        <div className="legend">
          <div className="legend-item">
            <div className="legend-seat available"></div>
            <span>Available</span>
          </div>
          <div className="legend-item">
            <div className="legend-seat selected"></div>
            <span>Selected</span>
          </div>
          <div className="legend-item">
            <div className="legend-seat booked"></div>
            <span>Booked</span>
          </div>
          <div className="legend-item">
            <div className="legend-seat pending"></div>
            <span>Pending</span>
          </div>
        </div>

        <div className="screen">Screen</div>

        <div className="seats-grid">
          {Array.from({ length: rows }, (_, rowIndex) => (
            <div key={rowIndex} className="seat-row">
              {Array.from({ length: seatsPerRow }, (_, colIndex) => {
                const seatNumber = rowIndex * seatsPerRow + colIndex + 1
                if (seatNumber > seatInfo.totalSeats) return null

                const status = getSeatStatus(seatNumber)
                return (
                  <button
                    key={seatNumber}
                    ref={(el) => {
                      seatRefs.current[seatNumber] = el
                    }}
                    className={`seat seat-${status}`}
                    onClick={() => handleSeatClick(seatNumber)}
                    disabled={status === 'booked' || status === 'pending'}
                    title={`Seat ${seatNumber} - ${status}`}
                  >
                    {seatNumber}
                  </button>
                )
              })}
            </div>
          ))}
        </div>

        <div className="booking-actions">
          <div className="selected-seats-info">
            {selectedSeats.length > 0 ? (
              <p>
                Selected: {selectedSeats.sort((a, b) => a - b).join(', ')} ({selectedSeats.length} seat{selectedSeats.length > 1 ? 's' : ''})
              </p>
            ) : (
              <p>Select seats to book</p>
            )}
          </div>
          <button
            onClick={handleBooking}
            disabled={selectedSeats.length === 0 || bookingLoading}
            className="book-button"
          >
            {bookingLoading ? 'Booking...' : `Book ${selectedSeats.length} Seat${selectedSeats.length !== 1 ? 's' : ''}`}
          </button>
        </div>
      </div>
    </div>
  )
}

export default BookingPage



