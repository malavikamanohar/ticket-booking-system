# System Design Document - Ticket Booking System

## High-Level Architecture

```
┌─────────────┐
│   Client    │
│  (Browser)  │
└──────┬──────┘
       │
       │ HTTP/REST
       │
┌──────▼─────────────────────────────────────┐
│         Frontend (React + TypeScript)      │
│  - Admin Dashboard                         │
│  - User Interface                          │
│  - Seat Selection                          │
└──────┬─────────────────────────────────────┘
       │
       │ REST API
       │
┌──────▼─────────────────────────────────────┐
│      Backend API (Node.js + Express)       │
│  - Show Management                          │
│  - Booking Operations                       │
│  - Concurrency Control                      │
└──────┬─────────────────────────────────────┘
       │
       │ SQL Queries
       │
┌──────▼─────────────────────────────────────┐
│      PostgreSQL Database                    │
│  - Shows Table                              │
│  - Bookings Table                           │
│  - Indexes for Performance                   │
└─────────────────────────────────────────────┘
```

## Key Components

### 1. Frontend (React + TypeScript)
- **Pages**: Admin Dashboard, Show List, Booking Page
- **State Management**: React Context API
- **API Integration**: Axios for HTTP requests
- **Real-time Updates**: Polling mechanism for seat availability

### 2. Backend API (Node.js + Express)
- **Controllers**: Handle business logic
- **Models**: Data access layer
- **Routes**: API endpoint definitions
- **Middleware**: Error handling, validation

### 3. Database (PostgreSQL)
- **Shows Table**: Stores show/trip information
- **Bookings Table**: Stores booking records with status
- **Indexes**: Optimized for query performance

## Database Design

### Tables

#### Shows Table
```sql
CREATE TABLE shows (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  start_time TIMESTAMP NOT NULL,
  total_seats INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Bookings Table
```sql
CREATE TABLE bookings (
  id SERIAL PRIMARY KEY,
  show_id INTEGER NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
  user_id VARCHAR(255) NOT NULL,
  seat_numbers INTEGER[] NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP,
  FOREIGN KEY (show_id) REFERENCES shows(id)
);
```

### Indexes
- `idx_bookings_show_id` on `bookings(show_id)` - Fast lookups by show
- `idx_bookings_status` on `bookings(status)` - Fast status queries
- `idx_bookings_expires_at` on `bookings(expires_at)` - Efficient expiry cleanup

## Concurrency Control Mechanisms

### 1. Database Transactions
All booking operations are wrapped in transactions to ensure atomicity:
```javascript
await client.query('BEGIN');
// ... booking logic ...
await client.query('COMMIT');
```

### 2. Row-Level Locking
Uses `SELECT FOR UPDATE` to lock rows during booking:
```sql
SELECT seat_numbers 
FROM bookings 
WHERE show_id = $1 
AND status IN ('CONFIRMED', 'PENDING')
FOR UPDATE
```

### 3. Conflict Detection
Before confirming a booking, the system checks for conflicts:
- Checks if seats are already booked (CONFIRMED)
- Checks if seats are pending (PENDING with valid expiry)
- Uses PostgreSQL array overlap operator (`&&`) for efficient conflict detection

### 4. Booking Expiry
- PENDING bookings expire after 2 minutes
- Background job runs every 30 seconds to mark expired bookings as FAILED
- Expired bookings release seats back to available pool

## Scalability Considerations

### Database Scaling

#### 1. Read Replicas
- Deploy read replicas for read-heavy operations
- Route read queries to replicas
- Keep writes on primary database

#### 2. Sharding Strategy
For horizontal scaling, shard by `show_id`:
- Partition shows across multiple databases
- Use consistent hashing for show distribution
- Maintain referential integrity within shards

#### 3. Connection Pooling
- Use connection pooling (pg Pool) to manage database connections
- Configure pool size based on load
- Monitor connection usage

### Caching Strategy

#### 1. Redis Cache
- Cache show listings (TTL: 1 minute)
- Cache seat availability (TTL: 5 seconds)
- Invalidate cache on booking creation/confirmation

#### 2. Cache Layers
```
Client → CDN → Application Cache → Database
```

### Message Queue Usage

#### 1. Decoupling Critical Operations
Use message queues (RabbitMQ, AWS SQS) for:
- Booking confirmation notifications
- Email/SMS notifications
- Analytics events
- Audit logging

#### 2. Queue Architecture
```
Booking Request → API → Queue → Worker → Database
                              ↓
                         Notification Service
```

### Load Balancing

#### 1. Application Load Balancer
- Distribute requests across multiple backend instances
- Health checks for instance availability
- Session affinity if needed

#### 2. Database Load Balancer
- Route read queries to read replicas
- Route write queries to primary database

## Production-Grade Enhancements

### 1. Monitoring & Logging
- **Application Logging**: Winston or Pino for structured logging
- **Error Tracking**: Sentry for error monitoring
- **Performance Monitoring**: New Relic or DataDog
- **Database Monitoring**: pg_stat_statements for query analysis

### 2. Security
- **Authentication**: JWT tokens for user authentication
- **Authorization**: Role-based access control (RBAC)
- **Rate Limiting**: Prevent abuse (express-rate-limit)
- **Input Validation**: Comprehensive validation on all inputs
- **SQL Injection Prevention**: Parameterized queries (already implemented)

### 3. High Availability
- **Database Replication**: Master-slave replication
- **Backup Strategy**: Daily backups with point-in-time recovery
- **Failover**: Automatic failover to standby database
- **Health Checks**: Regular health check endpoints

### 4. Performance Optimization
- **Database Query Optimization**: Analyze slow queries
- **Index Optimization**: Add indexes based on query patterns
- **API Response Caching**: Cache frequently accessed data
- **CDN**: Serve static assets via CDN

### 5. Additional Features
- **Payment Integration**: Stripe/PayPal for payments
- **Email Notifications**: Send booking confirmations
- **Booking History**: User booking history page
- **Cancellation**: Allow users to cancel bookings
- **Waitlist**: Queue users when shows are full

## Architecture Diagram (Scaled System)

```
                    ┌─────────────┐
                    │   CDN        │
                    │  (Static)    │
                    └──────┬───────┘
                           │
                    ┌──────▼──────────────────────────┐
                    │   Load Balancer                 │
                    └──────┬──────────────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
┌───────▼──────┐  ┌───────▼──────┐  ┌───────▼──────┐
│  Backend     │  │  Backend      │  │  Backend     │
│  Instance 1  │  │  Instance 2   │  │  Instance N  │
└──────┬───────┘  └──────┬────────┘  └──────┬───────┘
       │                 │                  │
       └─────────────────┼──────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
┌───────▼──────┐  ┌───────▼──────┐  ┌───────▼──────┐
│   Redis      │  │  PostgreSQL  │  │   Queue      │
│   Cache      │  │  Primary     │  │  (RabbitMQ)  │
└──────────────┘  └──────┬───────┘  └──────┬───────┘
                         │                  │
                  ┌──────▼──────┐  ┌───────▼──────┐
                  │ PostgreSQL  │  │   Workers    │
                  │  Replicas   │  │  (Notifications)│
                  └─────────────┘  └───────────────┘
```

## Conclusion

This system is designed to handle high concurrency scenarios while maintaining data consistency. The architecture can scale horizontally by adding more instances, implementing caching, and using message queues for decoupling. The database design supports efficient queries and prevents overbooking through proper concurrency control mechanisms.



