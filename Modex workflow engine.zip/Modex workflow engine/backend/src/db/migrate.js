const pool = require('./config');

async function migrate() {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');

    // Create shows table
    await client.query(`
      CREATE TABLE IF NOT EXISTS shows (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        start_time TIMESTAMP NOT NULL,
        total_seats INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create bookings table
    await client.query(`
      CREATE TABLE IF NOT EXISTS bookings (
        id SERIAL PRIMARY KEY,
        show_id INTEGER NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
        user_id VARCHAR(255) NOT NULL,
        seat_numbers INTEGER[] NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expires_at TIMESTAMP,
        FOREIGN KEY (show_id) REFERENCES shows(id)
      )
    `);

    // Create index on show_id for faster lookups
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_bookings_show_id ON bookings(show_id)
    `);

    // Create index on status for expiry queries
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status)
    `);

    // Create index on expires_at for expiry cleanup
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_bookings_expires_at ON bookings(expires_at)
    `);

    await client.query('COMMIT');
    console.log('Migration completed successfully');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Migration failed:', error);
    throw error;
  } finally {
    client.release();
  }
}

if (require.main === module) {
  migrate()
    .then(() => {
      console.log('Database migration completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Migration error:', error);
      process.exit(1);
    });
}

module.exports = migrate;



