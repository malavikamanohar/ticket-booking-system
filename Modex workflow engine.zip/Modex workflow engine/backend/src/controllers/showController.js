const Show = require('../models/Show');
const { validationResult } = require('express-validator');

class ShowController {
  async createShow(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { name, startTime, totalSeats } = req.body;

      if (!name || !startTime || !totalSeats) {
        return res.status(400).json({ 
          error: 'Missing required fields: name, startTime, totalSeats' 
        });
      }

      if (totalSeats < 1) {
        return res.status(400).json({ 
          error: 'Total seats must be at least 1' 
        });
      }

      const show = await Show.create(name, startTime, totalSeats);
      res.status(201).json({ 
        message: 'Show created successfully',
        show 
      });
    } catch (error) {
      console.error('Error creating show:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getAllShows(req, res) {
    try {
      const shows = await Show.findAll();
      res.json({ shows });
    } catch (error) {
      console.error('Error fetching shows:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getShowById(req, res) {
    try {
      const { id } = req.params;
      const show = await Show.findById(id);
      
      if (!show) {
        return res.status(404).json({ error: 'Show not found' });
      }

      res.json({ show });
    } catch (error) {
      console.error('Error fetching show:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getAvailableSeats(req, res) {
    try {
      const { id } = req.params;
      const seatInfo = await Show.getAvailableSeats(id);
      res.json(seatInfo);
    } catch (error) {
      console.error('Error fetching available seats:', error);
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new ShowController();



