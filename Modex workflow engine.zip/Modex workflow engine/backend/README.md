# Ticket Booking System - Backend API

A robust ticket booking system backend built with Node.js, Express.js, and PostgreSQL. Handles high concurrency scenarios to prevent race conditions and overbooking.

## Features

- **Show/Trip Management**: Admin can create shows with name, start time, and total seats
- **User Operations**: Users can view available shows and book seats
- **Concurrency Handling**: Prevents overbooking using database transactions and row-level locking
- **Booking Status**: Supports PENDING, CONFIRMED, and FAILED statuses
- **Automatic Expiry**: PENDING bookings expire after 2 minutes and are marked as FAILED

## Tech Stack

- Node.js
- Express.js
- PostgreSQL
- pg (PostgreSQL client)

## Setup Instructions

### Prerequisites

- Node.js (v14 or higher)
- PostgreSQL (v12 or higher)

### Installation

1. Install dependencies:
```bash
npm install
```

2. Set up environment variables:
```bash
cp .env.example .env
```

Edit `.env` with your database credentials:
```
PORT=3001
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ticket_booking
DB_USER=postgres
DB_PASSWORD=postgres
NODE_ENV=development
```

3. Create PostgreSQL database:
```bash
createdb ticket_booking
```

4. Run migrations:
```bash
npm run migrate
```

5. Start the server:
```bash
# Development mode (with nodemon)
npm run dev

# Production mode
npm start
```

The server will start on `http://localhost:3001`

## API Documentation

### Shows

#### Create Show
```
POST /api/shows
Content-Type: application/json

{
  "name": "Movie Show 1",
  "startTime": "2024-12-25T18:00:00Z",
  "totalSeats": 40
}
```

#### Get All Shows
```
GET /api/shows
```

#### Get Show by ID
```
GET /api/shows/:id
```

#### Get Available Seats
```
GET /api/shows/:id/seats
```

### Bookings

#### Create Booking
```
POST /api/bookings
Content-Type: application/json

{
  "showId": 1,
  "userId": "user123",
  "seatNumbers": [1, 2, 3]
}
```

#### Confirm Booking
```
PUT /api/bookings/:id/confirm
```

#### Get Booking by ID
```
GET /api/bookings/:id
```

#### Get User Bookings
```
GET /api/bookings/user/:userId
```

## Concurrency Handling

The system uses PostgreSQL transactions with `SELECT FOR UPDATE` to lock rows during booking operations, ensuring atomicity and preventing race conditions. When multiple users try to book the same seats simultaneously, only one booking succeeds.

## Booking Expiry

PENDING bookings automatically expire after 2 minutes. A background job runs every 30 seconds to check and mark expired bookings as FAILED.

## Database Schema

### Shows Table
- `id` (SERIAL PRIMARY KEY)
- `name` (VARCHAR)
- `start_time` (TIMESTAMP)
- `total_seats` (INTEGER)
- `created_at` (TIMESTAMP)
- `updated_at` (TIMESTAMP)

### Bookings Table
- `id` (SERIAL PRIMARY KEY)
- `show_id` (INTEGER, FOREIGN KEY)
- `user_id` (VARCHAR)
- `seat_numbers` (INTEGER[])
- `status` (VARCHAR) - PENDING, CONFIRMED, or FAILED
- `created_at` (TIMESTAMP)
- `expires_at` (TIMESTAMP)

## Testing

You can test the API using Postman, curl, or any HTTP client. Example:

```bash
# Create a show
curl -X POST http://localhost:3001/api/shows \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Show","startTime":"2024-12-25T18:00:00Z","totalSeats":40}'

# Get all shows
curl http://localhost:3001/api/shows

# Create a booking
curl -X POST http://localhost:3001/api/bookings \
  -H "Content-Type: application/json" \
  -d '{"showId":1,"userId":"user1","seatNumbers":[1,2]}'
```



