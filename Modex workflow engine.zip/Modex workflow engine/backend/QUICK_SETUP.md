# Quick Setup Guide - Update PostgreSQL Password

## Option 1: Using PowerShell Script (Recommended)

Run this command in PowerShell from the `backend` folder:

```powershell
.\update-env-password.ps1 -Password "your_actual_password"
```

Replace `your_actual_password` with your PostgreSQL password.

## Option 2: Manual Update

1. Open `backend/.env` file in a text editor
2. Find the line: `DB_PASSWORD=postgres`
3. Change it to: `DB_PASSWORD=your_actual_password`
4. Save the file

## Option 3: Using Command Line

```powershell
cd backend
(Get-Content .env) -replace 'DB_PASSWORD=postgres', 'DB_PASSWORD=your_actual_password' | Set-Content .env
```

Replace `your_actual_password` with your actual password.

## After Updating Password

Once you've updated the password, run these commands:

```powershell
cd backend

# Create database
node src/db/createDatabase.js

# Run migrations
npm run migrate

# Start backend server
npm run dev
```

## Finding Your PostgreSQL Password

If you don't remember your PostgreSQL password:

1. **Check pgAdmin**: If you have pgAdmin installed, the password might be saved there
2. **Check installation notes**: Check any notes from when you installed PostgreSQL
3. **Reset password**: You can reset it using pgAdmin or command line tools
4. **Default during installation**: Many installations use "postgres" as default - if that doesn't work, you may have changed it during installation

## Need Help?

If you're stuck, you can:
- Check PostgreSQL service logs
- Try resetting the password using pgAdmin
- Reinstall PostgreSQL (last resort)


