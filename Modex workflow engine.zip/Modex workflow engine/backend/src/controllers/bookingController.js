const Booking = require('../models/Booking');
const { validationResult } = require('express-validator');

class BookingController {
  async createBooking(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { showId, userId, seatNumbers } = req.body;

      if (!showId || !userId || !seatNumbers || !Array.isArray(seatNumbers)) {
        return res.status(400).json({ 
          error: 'Missing required fields: showId, userId, seatNumbers (array)' 
        });
      }

      if (seatNumbers.length === 0) {
        return res.status(400).json({ 
          error: 'At least one seat must be selected' 
        });
      }

      const booking = await Booking.create(showId, userId, seatNumbers);
      res.status(201).json({ 
        message: 'Booking created successfully',
        booking 
      });
    } catch (error) {
      console.error('Error creating booking:', error);
      
      if (error.message.includes('not found') || 
          error.message.includes('Invalid seat') ||
          error.message.includes('already booked')) {
        return res.status(400).json({ error: error.message });
      }

      res.status(500).json({ error: error.message });
    }
  }

  async confirmBooking(req, res) {
    try {
      const { id } = req.params;
      const booking = await Booking.confirm(id);
      res.json({ 
        message: 'Booking confirmed successfully',
        booking 
      });
    } catch (error) {
      console.error('Error confirming booking:', error);
      
      if (error.message.includes('not found') || 
          error.message.includes('already') ||
          error.message.includes('expired') ||
          error.message.includes('no longer available')) {
        return res.status(400).json({ error: error.message });
      }

      res.status(500).json({ error: error.message });
    }
  }

  async getBookingById(req, res) {
    try {
      const { id } = req.params;
      const booking = await Booking.findById(id);
      
      if (!booking) {
        return res.status(404).json({ error: 'Booking not found' });
      }

      res.json({ booking });
    } catch (error) {
      console.error('Error fetching booking:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getUserBookings(req, res) {
    try {
      const { userId } = req.params;
      const bookings = await Booking.findByUserId(userId);
      res.json({ bookings });
    } catch (error) {
      console.error('Error fetching user bookings:', error);
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new BookingController();



