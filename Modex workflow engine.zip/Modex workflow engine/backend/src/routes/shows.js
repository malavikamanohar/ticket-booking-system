const express = require('express');
const router = express.Router();
const showController = require('../controllers/showController');
const { body } = require('express-validator');

router.post(
  '/',
  [
    body('name').notEmpty().withMessage('Name is required'),
    body('startTime').notEmpty().withMessage('Start time is required'),
    body('totalSeats').isInt({ min: 1 }).withMessage('Total seats must be a positive integer')
  ],
  showController.createShow
);

router.get('/', showController.getAllShows);
router.get('/:id', showController.getShowById);
router.get('/:id/seats', showController.getAvailableSeats);

module.exports = router;



