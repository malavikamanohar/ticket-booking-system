const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');
const { body } = require('express-validator');

router.post(
  '/',
  [
    body('showId').isInt().withMessage('Show ID must be an integer'),
    body('userId').notEmpty().withMessage('User ID is required'),
    body('seatNumbers').isArray({ min: 1 }).withMessage('Seat numbers must be a non-empty array'),
    body('seatNumbers.*').isInt({ min: 1 }).withMessage('Each seat number must be a positive integer')
  ],
  bookingController.createBooking
);

router.put('/:id/confirm', bookingController.confirmBooking);
router.get('/:id', bookingController.getBookingById);
router.get('/user/:userId', bookingController.getUserBookings);

module.exports = router;



