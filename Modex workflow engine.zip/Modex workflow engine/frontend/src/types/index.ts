export interface Show {
  id: number;
  name: string;
  start_time: string;
  total_seats: number;
  created_at: string;
  updated_at: string;
  booked_seats_count?: number;
  pending_bookings_count?: number;
}

export interface Booking {
  id: number;
  show_id: number;
  user_id: string;
  seat_numbers: number[];
  status: 'PENDING' | 'CONFIRMED' | 'FAILED';
  created_at: string;
  expires_at: string | null;
  show_name?: string;
  start_time?: string;
}

export interface SeatInfo {
  totalSeats: number;
  availableSeats: number[];
  bookedSeats: number[];
  pendingSeats: number[];
}

export interface User {
  id: string;
  name: string;
  role: 'admin' | 'user';
}



