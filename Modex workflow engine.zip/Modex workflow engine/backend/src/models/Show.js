const pool = require('../db/config');

class Show {
  static async create(name, startTime, totalSeats) {
    const query = `
      INSERT INTO shows (name, start_time, total_seats)
      VALUES ($1, $2, $3)
      RETURNING *
    `;
    const result = await pool.query(query, [name, startTime, totalSeats]);
    return result.rows[0];
  }

  static async findAll() {
    const query = `
      SELECT 
        s.*,
        COUNT(DISTINCT CASE WHEN b.status = 'CONFIRMED' THEN b.id END) as booked_seats_count,
        COUNT(DISTINCT CASE WHEN b.status = 'PENDING' THEN b.id END) as pending_bookings_count
      FROM shows s
      LEFT JOIN bookings b ON s.id = b.show_id
      GROUP BY s.id
      ORDER BY s.start_time ASC
    `;
    const result = await pool.query(query);
    return result.rows;
  }

  static async findById(id) {
    const query = 'SELECT * FROM shows WHERE id = $1';
    const result = await pool.query(query, [id]);
    return result.rows[0];
  }

  static async getAvailableSeats(showId) {
    const show = await this.findById(showId);
    if (!show) {
      throw new Error('Show not found');
    }

    // Get all confirmed bookings for this show
    const bookingsQuery = `
      SELECT seat_numbers 
      FROM bookings 
      WHERE show_id = $1 AND status = 'CONFIRMED'
    `;
    const bookingsResult = await pool.query(bookingsQuery, [showId]);
    
    const bookedSeats = new Set();
    bookingsResult.rows.forEach(booking => {
      booking.seat_numbers.forEach(seat => bookedSeats.add(seat));
    });

    // Get pending bookings (seats that are being booked)
    const pendingQuery = `
      SELECT seat_numbers 
      FROM bookings 
      WHERE show_id = $1 AND status = 'PENDING' AND expires_at > NOW()
    `;
    const pendingResult = await pool.query(pendingQuery, [showId]);
    
    const pendingSeats = new Set();
    pendingResult.rows.forEach(booking => {
      booking.seat_numbers.forEach(seat => pendingSeats.add(seat));
    });

    const allSeats = Array.from({ length: show.total_seats }, (_, i) => i + 1);
    const availableSeats = allSeats.filter(seat => 
      !bookedSeats.has(seat) && !pendingSeats.has(seat)
    );

    return {
      totalSeats: show.total_seats,
      availableSeats,
      bookedSeats: Array.from(bookedSeats),
      pendingSeats: Array.from(pendingSeats)
    };
  }
}

module.exports = Show;



