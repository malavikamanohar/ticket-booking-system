# Quick Setup Guide

## Prerequisites

Before starting, ensure you have installed:
- **Node.js** (v16 or higher) - [Download](https://nodejs.org/)
- **PostgreSQL** (v12 or higher) - [Download](https://www.postgresql.org/download/)

## Step-by-Step Setup

### 1. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Create .env file (copy from example)
# Windows:
copy .env.example .env
# Linux/Mac:
cp .env.example .env

# Edit .env file with your PostgreSQL credentials:
# PORT=3001
# DB_HOST=localhost
# DB_PORT=5432
# DB_NAME=ticket_booking
# DB_USER=postgres
# DB_PASSWORD=your_password

# Create PostgreSQL database
# Windows (Command Prompt):
createdb ticket_booking
# Or using psql:
psql -U postgres -c "CREATE DATABASE ticket_booking;"

# Run database migrations
npm run migrate

# Start the backend server
npm run dev
```

Backend should now be running on `http://localhost:3001`

### 2. Frontend Setup

Open a new terminal window:

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# (Optional) Create .env file if backend is not on localhost:3001
# echo "VITE_API_URL=http://localhost:3001/api" > .env

# Start the frontend development server
npm run dev
```

Frontend should now be running on `http://localhost:3000`

### 3. Test the Application

1. Open your browser and go to `http://localhost:3000`
2. Click on "Admin" in the navigation
3. Create a new show:
   - Enter show name (e.g., "Movie Show 1")
   - Select start time
   - Enter total seats (e.g., 40)
   - Click "Create Show"
4. Go back to the home page
5. Click "Book Now" on the show you created
6. Select seats and click "Book"

## Troubleshooting

### Database Connection Issues

If you get database connection errors:

1. Make sure PostgreSQL is running:
   ```bash
   # Windows
   # Check Services or use pg_ctl
   
   # Linux/Mac
   sudo service postgresql status
   ```

2. Verify your database credentials in `.env` file

3. Test connection:
   ```bash
   psql -U postgres -d ticket_booking
   ```

### Port Already in Use

If port 3001 or 3000 is already in use:

1. Change the port in backend `.env` file:
   ```
   PORT=3002
   ```

2. Update frontend `.env` file:
   ```
   VITE_API_URL=http://localhost:3002/api
   ```

### Migration Errors

If migrations fail:

1. Drop and recreate the database:
   ```bash
   dropdb ticket_booking
   createdb ticket_booking
   npm run migrate
   ```

2. Check PostgreSQL logs for detailed error messages

## API Testing

You can test the API using:

1. **Postman**: Import `backend/postman_collection.json`
2. **curl**: See examples in backend README.md
3. **Browser**: Visit `http://localhost:3001/health` for health check

## Production Deployment

See the main README.md for deployment instructions to:
- Vercel/Netlify (Frontend)
- Render/Railway/AWS (Backend)

## Need Help?

Check the detailed documentation:
- `README.md` - Main project documentation
- `SYSTEM_DESIGN.md` - Architecture and scalability details
- `backend/README.md` - Backend-specific documentation
- `frontend/README.md` - Frontend-specific documentation



