import axios from 'axios'
import { Show, Booking, SeatInfo } from '../types'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Shows API
export const getShows = async (): Promise<{ shows: Show[] }> => {
  const response = await api.get('/shows')
  return response.data
}

export const getShow = async (id: number): Promise<{ show: Show }> => {
  const response = await api.get(`/shows/${id}`)
  return response.data
}

export const createShow = async (data: {
  name: string
  startTime: string
  totalSeats: number
}): Promise<{ show: Show }> => {
  const response = await api.post('/shows', data)
  return response.data
}

export const getAvailableSeats = async (id: number): Promise<SeatInfo> => {
  const response = await api.get(`/shows/${id}/seats`)
  return response.data
}

// Bookings API
export const createBooking = async (data: {
  showId: number
  userId: string
  seatNumbers: number[]
}): Promise<{ booking: Booking }> => {
  const response = await api.post('/bookings', data)
  return response.data
}

export const confirmBooking = async (id: number): Promise<{ booking: Booking }> => {
  const response = await api.put(`/bookings/${id}/confirm`)
  return response.data
}

export const getBooking = async (id: number): Promise<{ booking: Booking }> => {
  const response = await api.get(`/bookings/${id}`)
  return response.data
}

export const getUserBookings = async (userId: string): Promise<{ bookings: Booking[] }> => {
  const response = await api.get(`/bookings/user/${userId}`)
  return response.data
}

export default api



