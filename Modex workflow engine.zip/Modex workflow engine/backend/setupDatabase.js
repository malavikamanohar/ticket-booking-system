require('dotenv').config();
const { Client } = require('pg');
const fs = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '.env');

// Common PostgreSQL passwords to try
const commonPasswords = ['postgres', '', 'admin', 'password', 'root', '123456'];

async function tryPassword(password) {
  const client = new Client({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: 'postgres',
    user: process.env.DB_USER || 'postgres',
    password: password,
  });

  try {
    await client.connect();
    await client.end();
    return true;
  } catch (error) {
    return false;
  }
}

async function updateEnvPassword(password) {
  let envContent = fs.readFileSync(envPath, 'utf8');
  envContent = envContent.replace(/DB_PASSWORD=.*/g, `DB_PASSWORD=${password}`);
  fs.writeFileSync(envPath, envContent, 'utf8');
  console.log('✅ Updated .env with working password');
}

async function createDatabase() {
  require('dotenv').config({ override: true });
  const { Client } = require('pg');
  
  const client = new Client({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: 'postgres',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD,
  });

  try {
    await client.connect();
    console.log('✅ Connected to PostgreSQL');

    const dbName = process.env.DB_NAME || 'ticket_booking';
    
    const checkResult = await client.query(
      `SELECT 1 FROM pg_database WHERE datname = $1`,
      [dbName]
    );

    if (checkResult.rows.length > 0) {
      console.log(`✅ Database '${dbName}' already exists`);
    } else {
      await client.query(`CREATE DATABASE ${dbName}`);
      console.log(`✅ Database '${dbName}' created successfully`);
    }
    
    await client.end();
    return true;
  } catch (error) {
    console.error('❌ Error:', error.message);
    await client.end();
    return false;
  }
}

async function main() {
  console.log('\n=== Setting up PostgreSQL Database ===\n');
  
  // Try current password first
  require('dotenv').config({ override: true });
  const currentPassword = process.env.DB_PASSWORD || 'postgres';
  
  console.log('Testing current password...');
  if (await tryPassword(currentPassword)) {
    console.log('✅ Current password works!');
    if (await createDatabase()) {
      console.log('\n✅ Database setup complete!');
      console.log('\nNext steps:');
      console.log('1. Run: npm run migrate');
      console.log('2. Run: npm run dev');
      process.exit(0);
    }
  } else {
    console.log('❌ Current password failed. Trying common passwords...\n');
    
    for (const pwd of commonPasswords) {
      if (pwd === currentPassword) continue; // Already tried
      
      console.log(`Trying password: ${pwd || '(empty)'}...`);
      if (await tryPassword(pwd)) {
        console.log(`✅ Found working password!`);
        await updateEnvPassword(pwd);
        
        // Reload env and create database
        if (await createDatabase()) {
          console.log('\n✅ Database setup complete!');
          console.log('\nNext steps:');
          console.log('1. Run: npm run migrate');
          console.log('2. Run: npm run dev');
          process.exit(0);
        }
        break;
      }
    }
    
    console.log('\n❌ Could not find working password.');
    console.log('\nPlease manually update backend/.env:');
    console.log('1. Open backend/.env');
    console.log('2. Change DB_PASSWORD=postgres to your actual password');
    console.log('3. Run: node src/db/createDatabase.js');
    process.exit(1);
  }
}

main();


