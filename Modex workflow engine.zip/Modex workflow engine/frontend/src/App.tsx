import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import { AppProvider } from './context/AppContext'
import AdminDashboard from './pages/AdminDashboard'
import ShowList from './pages/ShowList'
import BookingPage from './pages/BookingPage'
import './App.css'

function App() {
  return (
    <AppProvider>
      <Router>
        <div className="app">
          <nav className="navbar">
            <div className="nav-container">
              <Link to="/" className="nav-logo">
                🎫 Ticket Booking
              </Link>
              <div className="nav-links">
                <Link to="/" className="nav-link">Shows</Link>
                <Link to="/admin" className="nav-link">Admin</Link>
              </div>
            </div>
          </nav>

          <main className="main-content">
            <Routes>
              <Route path="/" element={<ShowList />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/booking/:id" element={<BookingPage />} />
            </Routes>
          </main>
        </div>
      </Router>
    </AppProvider>
  )
}

export default App



