# PowerShell script to update PostgreSQL password in .env file
param(
    [Parameter(Mandatory=$true)]
    [string]$Password
)

$envFile = Join-Path $PSScriptRoot ".env"

if (-not (Test-Path $envFile)) {
    Write-Host "❌ .env file not found at $envFile" -ForegroundColor Red
    exit 1
}

$content = Get-Content $envFile -Raw

# Update DB_PASSWORD
if ($content -match "DB_PASSWORD=.*") {
    $content = $content -replace "DB_PASSWORD=.*", "DB_PASSWORD=$Password"
    Set-Content -Path $envFile -Value $content -NoNewline
    Write-Host "✅ Password updated in .env file!" -ForegroundColor Green
} else {
    Write-Host "❌ DB_PASSWORD not found in .env file" -ForegroundColor Red
    exit 1
}

Write-Host "`nNext steps:" -ForegroundColor Cyan
Write-Host "1. Run: node src/db/createDatabase.js"
Write-Host "2. Run: npm run migrate"
Write-Host "3. Run: npm run dev"


