# Ticket Booking System - Frontend

A modern React + TypeScript frontend application for the ticket booking system.

## Features

- **Admin Dashboard**: Create and manage shows/trips
- **User Interface**: Browse available shows and book seats
- **Seat Selection**: Visual seat grid with real-time availability
- **State Management**: React Context API for global state
- **Error Handling**: Comprehensive error handling and validation
- **Responsive Design**: Works on mobile and desktop

## Tech Stack

- React 18
- TypeScript
- React Router DOM
- Vite
- Axios

## Setup Instructions

### Prerequisites

- Node.js (v16 or higher)
- Backend API running (see backend README)

### Installation

1. Install dependencies:
```bash
npm install
```

2. Create `.env` file (optional, defaults to localhost:3001):
```
VITE_API_URL=http://localhost:3001/api
```

3. Start development server:
```bash
npm run dev
```

The app will start on `http://localhost:3000`

4. Build for production:
```bash
npm run build
```

## Project Structure

```
src/
  ├── components/     # Reusable components
  ├── context/       # React Context providers
  ├── pages/         # Page components
  ├── services/      # API service functions
  ├── types/         # TypeScript type definitions
  └── App.tsx        # Main app component
```

## Routes

- `/` - Show list page (user view)
- `/admin` - Admin dashboard
- `/booking/:id` - Booking page for a specific show

## Features Implementation

### State Management
- Uses React Context API for global state
- Manages user, shows, and bookings state
- Provides loading and error states

### API Integration
- Efficient API calls with axios
- Error handling for API failures
- Automatic retry on errors

### Seat Selection
- Visual grid layout
- Real-time seat availability updates (polling every 5 seconds)
- Direct DOM manipulation for seat highlighting
- Prevents selection of booked/pending seats

### Error Handling
- Form validation
- API error messages
- User-friendly error displays
- Loading states

## Development

The frontend uses Vite for fast development and hot module replacement. Changes to files will automatically reload in the browser.

## Deployment

The frontend can be deployed to:
- Vercel
- Netlify
- Any static hosting service

Make sure to set the `VITE_API_URL` environment variable to your deployed backend URL.



