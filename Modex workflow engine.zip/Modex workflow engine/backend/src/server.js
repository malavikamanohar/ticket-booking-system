require('dotenv').config();
const express = require('express');
const cors = require('cors');
const showsRouter = require('./routes/shows');
const bookingsRouter = require('./routes/bookings');
const startExpiryJob = require('./middleware/expiryJob');
const migrate = require('./db/migrate');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'Ticket Booking API is running' });
});

// Routes
app.use('/api/shows', showsRouter);
app.use('/api/bookings', bookingsRouter);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Initialize database and start server
async function startServer() {
  try {
    // Run migrations
    await migrate();
    console.log('Database initialized');

    // Start expiry job
    startExpiryJob();
    console.log('Expiry job started');

    // Start server
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      console.log(`Health check: http://localhost:${PORT}/health`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();



