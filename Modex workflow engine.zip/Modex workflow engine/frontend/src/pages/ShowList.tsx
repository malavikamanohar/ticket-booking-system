import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { Show } from '../types'
import './ShowList.css'

const ShowList = () => {
  const { shows, loading, error, fetchShows } = useApp()
  const [localShows, setLocalShows] = useState<Show[]>([])

  useEffect(() => {
    if (shows.length === 0) {
      fetchShows()
    } else {
      setLocalShows(shows)
    }
  }, [shows, fetchShows])

  useEffect(() => {
    setLocalShows(shows)
  }, [shows])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const getAvailableSeats = (show: Show) => {
    const booked = show.booked_seats_count || 0
    const pending = show.pending_bookings_count || 0
    return show.total_seats - booked
  }

  if (loading && localShows.length === 0) {
    return (
      <div className="show-list-container">
        <div className="loading">Loading shows...</div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="show-list-container">
        <div className="error">Error: {error}</div>
        <button onClick={fetchShows} className="retry-button">
          Retry
        </button>
      </div>
    )
  }

  return (
    <div className="show-list-container">
      <h1>Available Shows</h1>
      
      {localShows.length === 0 ? (
        <div className="empty-state">
          <p>No shows available at the moment.</p>
          <Link to="/admin" className="link-button">
            Create a Show
          </Link>
        </div>
      ) : (
        <div className="shows-grid">
          {localShows.map((show) => (
            <div key={show.id} className="show-card">
              <div className="show-header">
                <h2>{show.name}</h2>
              </div>
              <div className="show-details">
                <div className="detail-item">
                  <span className="label">Start Time:</span>
                  <span className="value">{formatDate(show.start_time)}</span>
                </div>
                <div className="detail-item">
                  <span className="label">Total Seats:</span>
                  <span className="value">{show.total_seats}</span>
                </div>
                <div className="detail-item">
                  <span className="label">Available Seats:</span>
                  <span className="value available">{getAvailableSeats(show)}</span>
                </div>
              </div>
              <Link to={`/booking/${show.id}`} className="book-button">
                Book Now
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default ShowList



